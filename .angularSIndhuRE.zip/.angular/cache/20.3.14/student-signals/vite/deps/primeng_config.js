import {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
} from "./chunk-VXUFEIMB.js";
import "./chunk-G4CYJ7IC.js";
import "./chunk-ZA4DPHQT.js";
import "./chunk-VPKX4SO7.js";
import "./chunk-FAQCITYF.js";
import "./chunk-ILPDVII5.js";
import "./chunk-XWLXMCJQ.js";
export {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
};
