// import { Injectable, signal } from '@angular/core';

// @Injectable({
//   providedIn: 'root',
// })
// export class ThemeService {

//   isDarkTheme = signal<boolean>(false);

//   toggleTheme() {
//     this.isDarkTheme.set(!this.isDarkTheme());
//   }
  
// }
